export enum RoleEnum {
  // super admin
  SUPER = 1,

  // tester
  TEST = 2,
}
