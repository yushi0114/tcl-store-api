import { formatToDateTime } from '../utils'

/**
 * 病例管理
 */
import mysql from '../utils/mysql';

import type {
  IncomingOrderResultModel,
  Page,
  IUserInfo,
} from '../global/types';
import { buildUUID } from '../utils';
import { LabelValueOptions } from 'types';

class SaleServices {
  isExistOrder(data: IncomingOrderResultModel) {
    const { type, model } = data;
    const res = mysql.actionQuery(
      'sale_order',
      `type = '${type}' and model = '${model}'`
    ) as unknown as any[];
    return res;
  }
  // 新增
  async addSale(data: IncomingOrderResultModel, userInfo: IUserInfo) {
    const id = buildUUID();
    const { userId } = userInfo;
    const res = mysql.actionAdd('sale_order', {
      id,
      ...data,
      createBy: userId,
      updateBy: userId,
      createTime: formatToDateTime(),
      updateTime: formatToDateTime(),
    });
    return res;
  }

  // 编辑
  editSale(data: IncomingOrderResultModel, userInfo: IUserInfo) {
    const { userId } = userInfo;
    const res = mysql.actionUpdate('sale_order', { updateBy: userId, updateTime: formatToDateTime(), ...data}, ['id', data.id!]);
    return res;
  }

  // 删除
  deleteSale(id: Required<IncomingOrderResultModel['id']>) {
    const res = mysql.actionDelete('sale_order', ['id', id!]);
    return res;
  }

  // 分页
  async pageSale(data: Page) {
    const { pageNum, pageSize, type, model } = data;
    const res = mysql.actionPage('sale_order', data);
    return res;
  }

  // 查询销售单
  queryOuter(id: Required<IncomingOrderResultModel['id']>) {
    const res = mysql.actionQuery(
      'sale_order',
      `id = '${id}'`
    ) as unknown as IncomingOrderResultModel[];
    return res;
  }
}

export default new SaleServices();
