import type { IUserInfo } from './../src/global/types';
import type { Fn, Result } from './index';

declare module 'koa' {
  interface DefaultState {
    useRoutes?: (app: IApplication) => void;
    stateProperty: boolean;
  }

  interface DefaultContext {
    userInfo: IUserInfo;
    success: Fn<Partial<Result>, void>;
    error: Fn<Partial<Result>, void>;
  }
}
